import log

logger = log.get_logger(__name__)
logger.critical("Critical")
logger.info("Info")
logger.debug("Debug")
logger.warning("Warning")
logger.error("Error")